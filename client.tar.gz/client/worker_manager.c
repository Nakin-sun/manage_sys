#include "head.h"

int do_register_in(int socketfd,EMPLOYEE_MSG *msg)
{
	int err;
	msg->type = R;
	printf("Please input your name >:");
	scanf("%s",msg->employee_name);
	getchar();
	printf("Please input your passwd >:");
	scanf("%s",msg->employee_data);
	getchar();
	do
	{
		err = send(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("send()");
				return -1;
			}
		}
	}while(err < 0);

	do
	{
		err = recv(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("recv()");
				return -1;
			}
		}
	}while(err < 0);

	printf("%s\n",msg->employee_data);
	bzero(msg->employee_data,sizeof(msg->employee_data));

	return 0;
}

int do_login_in(int socketfd,EMPLOYEE_MSG *msg)
{
	int err;
	msg->type = L;
	
	printf("Please input your name >:");
	scanf("%s",msg->employee_name);
	getchar();
	printf("Please input your passwd >:");
	scanf("%s",msg->employee_data);
	getchar();

	do
	{
		err = send(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("send()");
				return -1;
			}
		}
	}while(err < 0);

	do
	{
		err = recv(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("recv()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close\n");
	}
	if(strncmp(msg->employee_data,"ok",3) == 0)
	{
		if(msg->flag == 1)
		{
			printf("welcom %s login successful\n",msg->employee_name);
			return 1;
		}
		if(msg->flag == 2)
		{
			printf("welcom %s login successful\n",msg->employee_name);
			return 2;
		}
	}
	else
	{
		printf("%s\n",msg->employee_data);
		return 0;
	}
	
}
/*
 *do admin step
 *
 */
int do_admin_step(int socketfd,EMPLOYEE_MSG *msg)
{
	puts("welcom admin coming");
	int choice_num;
	while(1)
	{
     	puts("********admin can do 1.add user 2.delete user 3.modify user 4.query user 5.exit****");
		printf("*****input your choice >:");
		fflush(NULL);
		scanf("%d",&choice_num);
		getchar();
		switch(choice_num)
		{
		case 1:
				do_add_user(socketfd,msg);
			break;
		case 2:
				do_delete_user(socketfd,msg);
			break;
		
		case 3:
				do_modify_user(socketfd,msg);
			break;
		case 4:
				do_query_user(socketfd,msg);
			break;
		case 5:
			return -1;

		}
	
	}
	
	
}


/*
 *添加用户信息
 */

int do_add_user(int socketfd,EMPLOYEE_MSG *msg)
{
	int err;
	msg->type = A;
	printf("Please input user name >:");
	scanf("%s",msg->name);
	getchar();
	
	printf("Please input user address >:");
	scanf("%s",msg->address);
	getchar();

	printf("Please input user age >:");
	scanf("%d",&msg->age);
	getchar();

	printf("Please input user phone num >:");
	scanf("%s",msg->phone_num);
	getchar();

	printf("Please input user salary >:");
	scanf("%lf",&msg->salary);
	getchar();
	
	printf("Please input user partment >:");
	scanf("%s",msg->partment);
	getchar();
	
	printf("Please input user level >:");
	scanf("%d",&msg->level);
	getchar();

	printf("Please input user job_num >:");
	scanf("%s",msg->job_num);
	getchar();

	do
	{
		err = send(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("send()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close \n");
	}

	do
	{
		err = recv(socketfd,msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("recv()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close\n");
	}

	if(strncmp(msg->employee_data,"ok",2) == 0)
	{
		printf("add user information is successful\n");
	}
	else
	{
		printf("add user failed\n");
		return 0;
	}
}

/*
 *删除用户信息
 */

int do_delete_user(int socketfd,EMPLOYEE_MSG *msg)
{
	msg->type = D;
	int err;
	printf("input your want to delet user based on phone >:");
	scanf("%s",msg->employee_data);
	getchar();

	do
	{
		err = send(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("send()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close \n");
	}

	do
	{
		err = recv(socketfd,msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("recv()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close\n");
	}

	if(strncmp(msg->employee_data,"ok",2) == 0)
	{
		printf("del user information  is successful\n");
	}
	else
	{
		printf("delete user information  failed\n");
	}
	return 0;
}

/*
 *修改用户信息
 */

int do_modify_user(int socketfd,EMPLOYEE_MSG *msg)
{
	msg->type = M;
	int err;
	int num;
	printf("input your want to modify user based on phone >:");
	scanf("%s",msg->employee_data);
	getchar();
	
	printf("Please input  new user name >:");
	scanf("%s",msg->name);
	getchar();
	
	printf("Please input new user address >:");
	scanf("%s",msg->address);
	getchar();

	printf("Please input new user age >:");
	scanf("%d",&msg->age);
	getchar();

	do
	{
		err = send(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("send()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close \n");
	}

	do
	{
		err = recv(socketfd,msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("recv()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close\n");
	}

	if(strncmp(msg->employee_data,"ok",2) == 0)
	{
		printf("modify user information  is successful\n");
		printf("%-15s",msg->name);
		printf("%-15s",msg->address);
		printf("%d",msg->age);
		putchar(10);
	}
	else
	{
		printf("modify user information  failed\n");
	}
}

/*
 *查询用户信息
 */


int do_query_user(int socketfd,EMPLOYEE_MSG *msg)
{
	msg->type = Q;
	
	int err;
	int num;
	printf("input your want to query user based on phone >:");
	scanf("%s",msg->employee_data);
	getchar();
	do
	{
		err = send(socketfd,(void *)msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("send()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close\n");
		return -1;
	}

	do
	{
		err = recv(socketfd,msg,sizeof(*msg),0);
		if(err < 0)
		{
			if(err != EINTR)
			{
				perror("recv()");
				return -1;
			}
		}
	}while(err < 0);
	if(err == 0)
	{
		printf("sever is close\n");
	}

	if(strncmp(msg->employee_data,"ok",2) == 0)
	{
		printf("modify user information  is successful\n");
		printf("%-15s",msg->name);
		printf("%-15s",msg->address);
		printf("%-15d",msg->age);
		printf("%-15s",msg->phone_num);
		printf("%-15lf",msg->salary);
		printf("%-15s",msg->partment);
		printf("%-15d",msg->level);
		printf("%-15s",msg->job_num);
		putchar(10);
	
	}

	else
	{
		printf("%s\n",msg->employee_data);
		return -1;
	}
	return 0;
}


int do_user_step(int socketfd,EMPLOYEE_MSG *msg)
{
	puts("welcoming to the warriors");
	int choice_num;
	while(1)
	{
		puts("*******1.查看信息 2.修改信息 3.退出********");
		printf("Please input your choice >:");
		scanf("%d",&choice_num);
		getchar();
		switch(choice_num)
		{
		case 1:
			do_query_user(socketfd,msg);
			break;
		case 2:
			do_modify_user(socketfd,msg);
			break;
		case 3:
			return 0;
		}
	}
	
}



