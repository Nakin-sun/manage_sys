#include "head.h"

int main(int argc, const char *argv[])
{
	EMPLOYEE_MSG Msg_eplopyee;

	SIGN_NUM Sign_num;
	OPERT_NUM Opert_num;
	struct sockaddr_in sin;
	int socketfd;
	int Choice_num;
	int err;
	int ID_num;
	socketfd = socket(AF_INET,SOCK_STREAM,0);
	if(socketfd < 0)
	{
		perror("socket()");
		exit(1);
	}
	bzero((void *)&sin,sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(PORT);
	sin.sin_addr.s_addr = inet_addr(IP_ADDR);
	err = connect(socketfd,(struct sockaddr *)&sin,sizeof(sin));
	if(err)
	{
		perror("connect()");
		exit(1);
	}
	puts("connect is ok");
	while(1)
	{
		
	   puts("************1.register 2.login_in 3.exit*********");
		printf("***Please input your choice >:");
		fflush(stdin);
		scanf("%d",&Choice_num);
		getchar();
		switch(Choice_num)
		{
		case Register_in:
			if(do_register_in(socketfd,&Msg_eplopyee))
			{
				printf("register fail\n");
				exit(1);
			}
			break;
		case LOGIN_IN:

			ID_num = do_login_in(socketfd,&Msg_eplopyee);
			if(ID_num == 1)
			{
				printf("admin\n");
				do_admin_step(socketfd,&Msg_eplopyee);
				break;
			}
			else if(ID_num == 2)
			{
				printf("common user \n");
				do_user_step(socketfd,&Msg_eplopyee);
				break;
			}
			else
			{
				break;	
			}
		
		case ESC_EXIT:
			close(socketfd);

			return 0;
	
		}
	
	}
	return 0;
}

