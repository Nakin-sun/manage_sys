#ifndef  __HEAD_H__
#define  __HEAD_H__


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#define IP_ADDR  "192.168.31.200"
#define PORT     6666

#define LENGTH_NAME     20
#define LENGTH_DATA   256
#define LENGTH_NUM    18
#define BUFLEN        100

#define R      1
#define L      2
#define A      3
#define D      4
#define M      5
#define Q      6


typedef struct employee_info
{
	int type;                //send to sever
	int flag;
	char employee_name[LENGTH_NAME];             //employee name
	char employee_data[LENGTH_DATA];     //word and passwd
	char name[LENGTH_NAME];
	char address[LENGTH_DATA];
	int age;
	char  phone_num[LENGTH_NUM];
	double salary;
	char partment[LENGTH_NAME];
	int level;
	char job_num[LENGTH_NUM];

}__attribute__((packed))EMPLOYEE_MSG;

typedef enum num_choice
{
	Register_in = 1,
	LOGIN_IN,
	ESC_EXIT,
}SIGN_NUM;

typedef enum operation
{
	add_user = 1,
	delete_user,
	modify_user,
	query_user,
	exit_user,
}OPERT_NUM;

int do_register_in(int socketfd,EMPLOYEE_MSG *msg);
int do_login_in(int socketfd,EMPLOYEE_MSG *msg);
int do_next_step(int socketfd,EMPLOYEE_MSG *msg);
int do_user_step(int socketfd,EMPLOYEE_MSG *msg);
int do_add_user(int socketfd,EMPLOYEE_MSG *msg);
#endif
